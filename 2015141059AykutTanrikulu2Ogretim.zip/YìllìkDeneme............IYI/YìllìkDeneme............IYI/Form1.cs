﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//access veritabani Kutuphanesi
using System.Data.OleDb;
//giris cikis Kutuphanesi
using System.IO;
//excel kutuphanesi
//using excel = Microsoft.Office.Interop.Excel;

namespace YıllıkDeneme._._._._._._._._._._._.IYI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //Global Degiskenler

        //kayitli ogrenciProfil.csv dosyasindaki verilerin aktarilacagi dizi.
        private String[,] ogrenci_Profil_Dizi = new String[90, 16];
        //kayitli ogrenciNetwork.csv dosyasindaki verilerin aktarilacagi dizi.
        private String[,] ogrenciNetworkdizi = new String[90, 11];
        //kayitli ogrencilistesi.xlsx dosyasindaki verilerin aktarilacagi dizi.
        private String[,] ogrenciListesidizi = new String[90, 2];
        //verileri veritabanina kaydetmek icin bir veritabanina ihtiyacimiz var
        //ben access veritabanini kullandim hem tasinmasi kolay hem verilere erisim daha rahat.
        OleDbConnection baglanti = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\\veritabani.mdb");
        OleDbCommand komut = new OleDbCommand();
        //41 arkadas icin:no,listeler,Label...
        double[,] profil = new double[41, 17];
        //41 arkadas olmayan liste icin:no,listeler,Label...
        double[,] yedek_profil = new double[49, 17];
        //ogrencinin kendi numarasi ve 10 arkadasinin kaydedilecegi dizi.
        double[] arkadaslar = new double[11];
        //ogrenciProfil dizisindeki liste degerlerini aliyoruz.
        //Ogrencinin numarasi ve label etiketi alinmayacak yani.
        //ilk ve son elemanini fonksiyona dahil etmiyoruz o yuzden dizinin degeri 15 olacak.
        double[] weights = new double[15];
        //bu diziye yeni arkadas olma ihtimali olan gorenci bilgileri eklenecek.
        // siralama islemi assagida...(Buyukten kucuge.)
        double[,] yeni_arkadas_listesi = new double[49, 2];
        //----------------excel acma islemleri...
        OleDbConnection xlsxbaglanti = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=d:\\ogrencilistesi.xlsx; Extended Properties='Excel 12.0 Xml;HDR=YES'"); //excel_dosya.xlsx kısmını kendi excel dosyanızın adıyla değiştirin.

        //***************************Fonksiyonlarin Baslangici*********************************

        //%%%%%%%%%%%%%%%%%%temizlik yapilacak alanlar%%%%%%%%%%%%%%%%%%%
        /*// DataTable tablo = new DataTable(); //Verileri direkt datagrid'e çekmek için DataTable kodunu tanımlıyoruz.
        private void excel_Verilerini_Aktar_Yedek()
        {//Exceldeki bütün verileri direk dataGridview1 e gönderiyor....
            xlsxbaglanti.Open(); //Excel dosyamızığın bağlantısını açıyoruz.
            tablo.Clear(); //En üstte tanımladığımız Datatable değişkenini temizliyoruz.
            OleDbDataAdapter da = new OleDbDataAdapter("SELECT * FROM [Sheet1$]", xlsxbaglanti); //OleDbDataAdapter ile excel dosyamızdaki verileri listeliyoruz. Burada önemli olan kısım sorgu cümleciğinde ki YeniSayfa$ kısmı yerine excel dosyasındaki ismi yazmanız gerek. Bu isim excel dosyanızı açtığınızda en altta yazan isimdir. Eğer değiştirmediyseniz zaten Sayfa1 olarak yazar. Ayrıca " $ " simgesi ve köşeli parentezleri ellememeniz gerek.
            da.Fill(tablo); //Gelen sonuçları datatable'a gönderiyoruz.
            dataGridView1.DataSource = tablo; //datatable'da ki verileri datagrid'de listeliyoruz.
            xlsxbaglanti.Close(); //Bağlantıyı kapatıyoruz.
        }*/
        //%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        private void excel_Verilerini_Aktar()
        {/*
            bu fonksiyon ogrencilistesi.xlsx excel dosyasindaki verileri satir satir alacak.
            bu verileri ogrenciListesidizi[,] dizisine aktaracak.
         */

            //Toplam kaç kayıt çektiğimizi anlamak için 
            //kayitsay adında bir değişken tanımlıyoruz.
            //Ayni zamanda dizi sayaci olacak.
            int kayitsay = 0;
            xlsxbaglanti.Open(); //Excel dosyamızın bağlantısını açıyoruz.
                                 //OleDbCommand ile excel dosyamızdaki verileri listeliyoruz. 
                                 //Burada önemli olan kısım sorgu cümleciğinde ki sayfa adini bilmeliyiz.
                                 //YeniSayfa$ 
                                 //kısmı yerine excel dosyasındaki ismi yazmanız gerek.
                                 //Bu isim excel dosyanızı açtığınızda en altta yazan isimdir.
                                 //Eğer değiştirmediyseniz zaten Sayfa1 olarak yazar. 
                                 //Ayrıca " $ " simgesi ve köşeli parentezleri ellememeniz gerek.
            OleDbCommand komut = new OleDbCommand("SELECT * FROM [Sheet1$]", xlsxbaglanti);
            //OleDbCommand ile gelen verileri tek tek okumak için 
            //OleDbDataReader sınıfındaki oku değişkenine atıyoruz. Ve...
            OleDbDataReader oku = komut.ExecuteReader();
            while (oku.Read()) //... Ardından verileri döngüye alıyoruz.
            {
                /*EXCEL veri cekmek icin genel bilgi..
                //Excel de ilk satırdaki alanlar başlık olarak kabul edilir. 
                //Bu bilgiye göre aşağıdaki kodlarımızı yazıyoruz. 
                //Yani ilk satırda "Öğrenci Numaranızı giriniz:" ve "Adınızı ve soyadınızı giriniz:" kısımları var. 
                //Bunların altında da bilgiler var. Biz bu başlıkların altındaki bilgileri çekiyoruz.
                */
                string ogrNo = oku["Öğrenci Numaranızı giriniz:"].ToString();
                string adSoyad = oku["Adınızı ve soyadınızı giriniz:"].ToString();
                ogrenciListesidizi[kayitsay, 0] = ogrNo;
                ogrenciListesidizi[kayitsay, 1] = adSoyad;
                kayitsay++; //Her döngüde sayacımız bir artıyoruz.
                            //Environment.NewLine messageBox komutu icin kodu bir alt satıra geçmek için kullanılmaktadır.
            }
            xlsxbaglanti.Close(); //Bağlantıyı kapatıyoruz.
        }//----------------excel Okuma islemleri Sonu...
         //**************************Metin Belgesi Komutlari******************************

        //%%%%%%%%%%%%%silinecek liste%%%%%%%%%%%%%%%%%%%%%
        //iki boyutlu bir diziye ihtiyacimiz olacak.
        //arkadas olma ihtimalini olcmek icin dizilere ihtiyacimiz olacak.
        //...
        /*    private void excel_Islem_Ekle()
            {   //yeni bir excel dosyasi aciyor.
                //dosyanin 2.satir 5. sutununa textbox1.text'in icindeki degeri yaziyor.
                //basarili sekilde calisiyor program....
                Microsoft.Office.Interop.Excel.Application uygulama = new Microsoft.Office.Interop.Excel.Application();
                uygulama.Visible = true;
                Microsoft.Office.Interop.Excel.Workbook kitap = uygulama.Workbooks.Add(System.Reflection.Missing.Value);
                Microsoft.Office.Interop.Excel.Worksheet sayfa1 = (Microsoft.Office.Interop.Excel.Worksheet)kitap.Sheets[1];
                Microsoft.Office.Interop.Excel.Range alan = (Microsoft.Office.Interop.Excel.Range)sayfa1.Cells[2,5];
                alan.Value2 = textBox1.Text;
            }
            //excelde kayitli satir veya sutunlari okuma...
            private void excel_Islem_Oku()
            {

            }
            //excelde kayitli satir veya sutunu silme...
            private void excel_Islem_Sil()
            {

            }*/
        //%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        private void ogrenciProfilOku()
        {   //bu fonksiyon ogrenciProfil.csv 'daki verileri okuyor. ve diziye ekliyor.
            //değerleri "," ile parcalara ayirip dizi ogrenci_Profil_Dizi dizisine aktariyor.
            int satir_No = 0;
            StreamReader oku = new StreamReader("d:\\ogrenciProfil.csv");
            String satir = null;
            //satir okuma islemlerine basliyoruz.
            satir = oku.ReadLine();
            String[] ogrenci_Profil_Dizi_No = new string[16];
            while (satir != null)
            {
                //diziye NOlar eklendi.
                //Dikkat String olarak...
                ogrenci_Profil_Dizi_No = satir.Split(',');
                for (int j = 0; j < ogrenci_Profil_Dizi_No.Length; j++)
                {
                    ogrenci_Profil_Dizi[satir_No, j] = ogrenci_Profil_Dizi_No[j];
                }
                satir = oku.ReadLine();
                satir_No++;
                if (satir_No >= 90)//if komutuna hic gerek yok ama sonsuz dongu ihtimalini dikkate almak gerek...
                    break;
            }
        }
        private void ogrenci_Network_Oku()
        {//ogrenciNetwork dosyasindaki verileri virgullere gore parcalayarak
         //okuyup ogrenciNetworkdizi dizisine aktariyor.
            int satir_No = 0;
            StreamReader oku = new StreamReader("d:\\ogrenciNetwork.csv");
            String satir = null;
            satir = oku.ReadLine();
            String[] ogrenci_Network_Dizi_No = new string[10];
            while (satir != null)
            {  //diziye NO'lar eklendi. //Dikkat String olarak..
                ogrenci_Network_Dizi_No = satir.Split(',');
                for (int j = 0; j < ogrenci_Network_Dizi_No.Length; j++)
                {
                    if (ogrenci_Network_Dizi_No[j] == "")//eger iki virgulun arasinda bisey yoksa 
                        ogrenci_Network_Dizi_No[j] = "0";//dizinin o degerine 0 degerini ata.
                    ogrenciNetworkdizi[satir_No, j] = ogrenci_Network_Dizi_No[j];
                }
                satir = oku.ReadLine();
                satir_No++;
                if (satir_No >= 90)//mutlu son dizi sonu.
                    break;
            }
        }
        //**************************Veritabani Komutlari********************************
        private void verilerigoruntule(string kayit)
        {/*
            bu fonksiyon sadece listeleme islemi yapacak.
            disardan string bir deger gelecek.
            string degere gore hangi veritabanindan hangi tablo 
            degerlerinin listelenecegi yazilmis olacagi bilgisi bulunacak.
            bu bilgiler sonucunda dataGridView tablosunda veriler listelenecek.
            
            //diger komutlar basit okuma islemleri icin gerekli komutlar...
            */
            baglanti.Open();
            komut.Connection = baglanti;
            komut.CommandText = (kayit);
            OleDbDataAdapter da = new OleDbDataAdapter(komut);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            baglanti.Close();
        }
        private void veritabani_Ogrenci_Profil_Ekle()
        {
            baglanti.Open();
            //dizinin adina ihtiyacimiz var ve 1 dizi sayacina ve for yada while dongusune...
            //dizi adi:ogrenci_Profil_Dizi
            int i = 0;
            while (i < ogrenci_Profil_Dizi.GetLength(0))
            {/*
                bu dongude sInIrlI sayacimiz ogrenci_Profil_Dizi dizisinin uzunlugu
                dongu uzunlugunu bu dizi length miktari belirleyecek.
                ic ice iki for kullanmadim.
                ogrenci_Profil_Dizi dizisinin butun 2. degerlerini elimle yazdim.
                */
                String listeNeler = "insert into ogrenciProfil(id,liste1,liste2,liste3,liste4,liste5,liste6,liste7,liste8,liste9,liste10,liste11,liste12,liste13,liste14,liste15)" +
                    " values(" +
                    "'" + ogrenci_Profil_Dizi[i, 0] + "','" + ogrenci_Profil_Dizi[i, 1] + "','" + ogrenci_Profil_Dizi[i, 2] + "'," +
                    "'" + ogrenci_Profil_Dizi[i, 3] + "','" + ogrenci_Profil_Dizi[i, 4] + "','" + ogrenci_Profil_Dizi[i, 5] + "'," +
                    "'" + ogrenci_Profil_Dizi[i, 6] + "','" + ogrenci_Profil_Dizi[i, 7] + "','" + ogrenci_Profil_Dizi[i, 8] + "'," +
                    "'" + ogrenci_Profil_Dizi[i, 9] + "','" + ogrenci_Profil_Dizi[i, 10] + "','" + ogrenci_Profil_Dizi[i, 11] + "'," +
                    "'" + ogrenci_Profil_Dizi[i, 12] + "','" + ogrenci_Profil_Dizi[i, 13] + "','" + ogrenci_Profil_Dizi[i, 14] + "'," +
                    "'" + ogrenci_Profil_Dizi[i, 15] + "')";
                komut.Connection = baglanti;
                komut.CommandText = (listeNeler);
                komut.ExecuteNonQuery();
                i++;
            }
            baglanti.Close();
        }

        private void veritabani_Ogrenci_Network_Ekle()
        {
            baglanti.Open();
            //dizinin adina ihtiyacimiz var ve 1 dizi sayacina ve for yada while dongusune...Dizi Boyutu:90,11 
            //dizi adi:ogrenciNetworkdizi
            /*
            ogrenciNetworkdizi dizisindeki degerleri 
            veritabanindaki ogrenciNetwork tablosuna ekliyoruz.
            */
            int i = 0;
            while (i < ogrenciNetworkdizi.GetLength(0))
            {
                String listeNeler = "insert into ogrenciNetwork(OgrNo,arkadas1,arkadas2,arkadas3,arkadas4,arkadas5,arkadas6,arkadas7,arkadas8,arkadas9,arkadas10)" +
                    " values(" +
                    "'" + ogrenciNetworkdizi[i, 0] + "','" + ogrenciNetworkdizi[i, 1] + "','" + ogrenciNetworkdizi[i, 2] + "'," +
                    "'" + ogrenciNetworkdizi[i, 3] + "','" + ogrenciNetworkdizi[i, 4] + "','" + ogrenciNetworkdizi[i, 5] + "'," +
                    "'" + ogrenciNetworkdizi[i, 6] + "','" + ogrenciNetworkdizi[i, 7] + "','" + ogrenciNetworkdizi[i, 8] + "'," +
                    "'" + ogrenciNetworkdizi[i, 9] + "','" + ogrenciNetworkdizi[i, 10] + "')";
                komut.Connection = baglanti;
                komut.CommandText = (listeNeler);
                komut.ExecuteNonQuery();
                i++;
            }
            baglanti.Close();
        }

        private void veritabani_Ogrenci_Listesi_Ekle()
        {
            baglanti.Open();
            //dizinin adina ihtiyacimiz var ve 1 dizi sayacina ve for yada while dongusune...Dizi Boyutu:90,11 
            //dizi adi:ogrenciListesidizi Boyutu: 90,2
            /*
            ogrenciListesidizi dizisindeki butun degerleri
            veritabanindaki ogrenciListesi tablosuna ekliyoruz.
            */
            int i = 0;
            while (i < ogrenciListesidizi.GetLength(0))
            {
                String listeNeler = "insert into ogrenciListesi(ogrNo,adSoyad)" +
                    " values(" +
                    "'" + ogrenciListesidizi[i, 0] + "','" + ogrenciListesidizi[i, 1] + "')";
                komut.Connection = baglanti;
                komut.CommandText = (listeNeler);
                komut.ExecuteNonQuery();
                i++;
            }//ekleme islemi basarili sekilde sonuclandi baglantimizi kapatiyoruz.
            baglanti.Close();
        }
        private void veritabani_veri_Sil(string listeNeler)
        { //veritabanindan veriler  silinecek...
            /*
            gelen string degerine gore gerekli tablodaki veriler silinecek.
            */
            baglanti.Open();
            komut.Connection = baglanti;
            komut.CommandText = (listeNeler);
            komut.ExecuteNonQuery();
            baglanti.Close();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            /*
            veriler once diziye eklenecek. 
            sonra veritabanina aktarilacak.
            bilgisayarimin performansi buna musaade ettigi icin boyle yaptim.
            diziye bos deger atama yerine 0 degeri atadim fonksiyonla.
            o acidan verilerin dosyadan diziye aktarilmasi sonra veritabanina aktarilmasi
            daha faydali oldu. o yuzden ogrenci profil veritabanina ekle butonu devredisi
            bu butona basilinca veriler diziye aktarilacak. sonra veritabanina ekle butonu aktif olacak.
            */
            button5.Enabled = true;
            ogrenciProfilOku();
            MessageBox.Show("OgrenciProfil diziye ekleme basarili.");
        }
        private void button2_Click(object sender, EventArgs e)
        {/*
            verilerin diziye aktarilmasini daha uygun buldum
            bilgisayarin performansinin artmasi icin.
            sonra veriler veritabanina aktarilabilecek.
            */
            button6.Enabled = true;
            ogrenci_Network_Oku();
            MessageBox.Show("OgrenciNetwork diziye ekleme basarili.");
        }
        private void button3_Click(object sender, EventArgs e)
        {/*
            exceldeki veriler diziye aktarilacak 
            sonra veritabanina ekleme butonu aktif olacak...
            */
            button7.Enabled = true;
            excel_Verilerini_Aktar();
            MessageBox.Show("Ogrencilistele diziye ekleme basarili.");
        }
        //*********button4 cehennemi************
        private void button4_Click(object sender, EventArgs e)
        {
            /*
             veritabanindan text teki degere gore arkadaslar alindi.
             dataGridview ile liste acilmiyacak.
             verilerin tek tek alinmasi gerek.
             */
            Array.Clear(weights, 0, weights.Length);//temiz regression katsayıları için..b0,b1,b2..b15 
            //degerlerini tekrar olusturmak icin temizliyoruz.
            string bak = textBox1.Text.ToString();
            //arkadas nolarini almak icin String.
            string adres = "SELECT * from ogrenciNetwork where OgrNo = '" + bak + "'";
            verilerigoruntule(adres);
            baglanti.Open();
            OleDbCommand kom = new OleDbCommand(adres, baglanti);
            OleDbDataReader okuyucu = kom.ExecuteReader();

            while (okuyucu.Read())
            {
                //int count = listView1.Items.Count;
                arkadaslar[0] = Convert.ToDouble(okuyucu["OgrNo"]);
                arkadaslar[1] = Convert.ToDouble(okuyucu["arkadas1"]);
                arkadaslar[2] = Convert.ToDouble(okuyucu["arkadas2"]);
                arkadaslar[3] = Convert.ToDouble(okuyucu["arkadas3"]);
                arkadaslar[4] = Convert.ToDouble(okuyucu["arkadas4"]);
                arkadaslar[5] = Convert.ToDouble(okuyucu["arkadas5"]);
                arkadaslar[6] = Convert.ToDouble(okuyucu["arkadas6"]);
                arkadaslar[7] = Convert.ToDouble(okuyucu["arkadas7"]);
                arkadaslar[8] = Convert.ToDouble(okuyucu["arkadas8"]);
                arkadaslar[9] = Convert.ToDouble(okuyucu["arkadas9"]);
                arkadaslar[10] = Convert.ToDouble(okuyucu["arkadas10"]);
            }
            /*
            //10 arkadasin bilgisini aldik.
            simdi her arkadas icin ogrenciProfil veritabanindan 
            arkadas olan kisilerin listesini alicas...
             */
            int sayac_Bak = 0;
            for (int i = 0; i < arkadaslar.Length; i++)
            {
                string liste_adres = "SELECT * from ogrenciProfil where id = '" + arkadaslar[i].ToString() + "'";
                OleDbCommand kom1 = new OleDbCommand(liste_adres, baglanti);
                OleDbDataReader okuyucu1 = kom1.ExecuteReader();

                while (okuyucu1.Read())
                {
                    /* 
                    bu while dongusu arkadas olanlari profil dizisine ekliyor.
                    ayrica sayac_Bak sayaci ile listede kac arkadasi oldugunu buldum.
                     bu sekile sayac_Bak sayacini 41'e tamamlama basarili olacak...:)

                    //dizi 0 degerlerini read etmedigi icin hic while ya girmiyor...:)
                    if (Convert.ToDouble(okuyucu1["id"]) == 0)
                         {
                             //  for(int k = 0; k < profil.GetLength(1); k++)
                             //     {profil[i, k] = 0;}
                             MessageBox.Show("0 a denk geldi degeri islemedi.");
                             continue;
                         }
                         */

                    profil[sayac_Bak, 0] = Convert.ToDouble(okuyucu1["id"]);
                    //MessageBox.Show("Arkadaslar listesine veriler ekleniyor:"+ profil[sayac_Bak, 0]);
                    profil[sayac_Bak, 1] = Convert.ToDouble(okuyucu1["liste1"]);
                    profil[sayac_Bak, 2] = Convert.ToDouble(okuyucu1["liste2"]);
                    profil[sayac_Bak, 3] = Convert.ToDouble(okuyucu1["liste3"]);
                    profil[sayac_Bak, 4] = Convert.ToDouble(okuyucu1["liste4"]);
                    profil[sayac_Bak, 5] = Convert.ToDouble(okuyucu1["liste5"]);
                    profil[sayac_Bak, 6] = Convert.ToDouble(okuyucu1["liste6"]);
                    profil[sayac_Bak, 7] = Convert.ToDouble(okuyucu1["liste7"]);
                    profil[sayac_Bak, 8] = Convert.ToDouble(okuyucu1["liste8"]);
                    profil[sayac_Bak, 9] = Convert.ToDouble(okuyucu1["liste8"]);
                    profil[sayac_Bak, 10] = Convert.ToDouble(okuyucu1["liste10"]);
                    profil[sayac_Bak, 11] = Convert.ToDouble(okuyucu1["liste11"]);
                    profil[sayac_Bak, 12] = Convert.ToDouble(okuyucu1["liste12"]);
                    profil[sayac_Bak, 13] = Convert.ToDouble(okuyucu1["liste13"]);
                    profil[sayac_Bak, 14] = Convert.ToDouble(okuyucu1["liste14"]);
                    profil[sayac_Bak, 15] = Convert.ToDouble(okuyucu1["liste15"]);
                    profil[sayac_Bak, 16] = 1;//dizi 16=Label degeri...yani arkadas mi label = 1 ise evet.
                    sayac_Bak++;
                }//while sonu
            }//for sonu

            //   MessageBox.Show("Arkadas degerleri basarili  sekilde veritabanindan alindi\n"
            //       +"Basarili sekilde diziye eklendi.\n Arkadas Sayisi sayac_Bak:"+sayac_Bak);
            /*
            arkadaslar dizisine ait liste veritabanindan alindi.
            simdi arkadas olmayan kisilerden diziyi 41 e tamamlayalim.
            */
            string liste_yedek_adres = "SELECT * from ogrenciProfil";
            OleDbCommand kom_yedek_1 = new OleDbCommand(liste_yedek_adres, baglanti);
            OleDbDataReader okuyucu_yedek_1 = kom_yedek_1.ExecuteReader();
            int say_Git = sayac_Bak;//say_git sayacina hic gerek yok ama baska bir islem yaptigimi hatirlamak icin yazdim.
            int biGitLanetOlasi = 0;//arkadas olmayan listeden alinacak verilerin adedi.
            bool yak = true;//arkadas olanlar listeye alinacak. true.
                            //eger arkadas olanlar listesi bitti ise 
                            //yak degeri false oluyor. o zaman label = 0 olarak
                            //veriler eklenecek.
            while (okuyucu_yedek_1.Read())
            {
                if (yak == true)
                {
                    if (say_Git >= profil.GetLength(0))
                    {/*
                        weigths dizisinin b0,b1,b2..b15 degerleri elde edilecek liste olusturmak icin
                        profil dizisini kullanacam.
                        gerekli miktarda(41 eleman) eleman alindiysa bu sefer 
                        yedek_Profil dizisine deger eklemesi yapilacak.
                        */
                     //  MessageBox.Show(biGitLanetOlasi + " tane eklendi:");
                        yak = false;
                        say_Git = 0;
                        continue;
                    }
                    profil[say_Git, 0] = Convert.ToDouble(okuyucu_yedek_1["id"]);
                    //   MessageBox.Show("eklendi:" + profil[say_Git, 0]);
                    profil[say_Git, 1] = Convert.ToDouble(okuyucu_yedek_1["liste1"]);
                    profil[say_Git, 2] = Convert.ToDouble(okuyucu_yedek_1["liste2"]);
                    profil[say_Git, 3] = Convert.ToDouble(okuyucu_yedek_1["liste3"]);
                    profil[say_Git, 4] = Convert.ToDouble(okuyucu_yedek_1["liste4"]);
                    profil[say_Git, 5] = Convert.ToDouble(okuyucu_yedek_1["liste5"]);
                    profil[say_Git, 6] = Convert.ToDouble(okuyucu_yedek_1["liste6"]);
                    profil[say_Git, 7] = Convert.ToDouble(okuyucu_yedek_1["liste7"]);
                    profil[say_Git, 8] = Convert.ToDouble(okuyucu_yedek_1["liste8"]);
                    profil[say_Git, 9] = Convert.ToDouble(okuyucu_yedek_1["liste8"]);
                    profil[say_Git, 10] = Convert.ToDouble(okuyucu_yedek_1["liste10"]);
                    profil[say_Git, 11] = Convert.ToDouble(okuyucu_yedek_1["liste11"]);
                    profil[say_Git, 12] = Convert.ToDouble(okuyucu_yedek_1["liste12"]);
                    profil[say_Git, 13] = Convert.ToDouble(okuyucu_yedek_1["liste13"]);
                    profil[say_Git, 14] = Convert.ToDouble(okuyucu_yedek_1["liste14"]);
                    profil[say_Git, 15] = Convert.ToDouble(okuyucu_yedek_1["liste15"]);
                    profil[say_Git, 16] = 0;//dizi 16=Label degeri...
                    say_Git++;
                    biGitLanetOlasi++;
                }
                else
                {

                    if (say_Git >= yedek_profil.GetLength(0))
                    {
                        //MessageBox.Show("Harici listeye"+say_Git + " tane eklendi:");
                        break;
                    }

                    //int[,] yedek_profil = new int[49, 17];
                    yedek_profil[say_Git, 0] = Convert.ToDouble(okuyucu_yedek_1["id"]);
                    // MessageBox.Show("eklendi:" + profil[say_Git, 0]);
                    yedek_profil[say_Git, 1] = Convert.ToDouble(okuyucu_yedek_1["liste1"]);
                    yedek_profil[say_Git, 2] = Convert.ToDouble(okuyucu_yedek_1["liste2"]);
                    yedek_profil[say_Git, 3] = Convert.ToDouble(okuyucu_yedek_1["liste3"]);
                    yedek_profil[say_Git, 4] = Convert.ToDouble(okuyucu_yedek_1["liste4"]);
                    yedek_profil[say_Git, 5] = Convert.ToDouble(okuyucu_yedek_1["liste5"]);
                    yedek_profil[say_Git, 6] = Convert.ToDouble(okuyucu_yedek_1["liste6"]);
                    yedek_profil[say_Git, 7] = Convert.ToDouble(okuyucu_yedek_1["liste7"]);
                    yedek_profil[say_Git, 8] = Convert.ToDouble(okuyucu_yedek_1["liste8"]);
                    yedek_profil[say_Git, 9] = Convert.ToDouble(okuyucu_yedek_1["liste8"]);
                    yedek_profil[say_Git, 10] = Convert.ToDouble(okuyucu_yedek_1["liste10"]);
                    yedek_profil[say_Git, 11] = Convert.ToDouble(okuyucu_yedek_1["liste11"]);
                    yedek_profil[say_Git, 12] = Convert.ToDouble(okuyucu_yedek_1["liste12"]);
                    yedek_profil[say_Git, 13] = Convert.ToDouble(okuyucu_yedek_1["liste13"]);
                    yedek_profil[say_Git, 14] = Convert.ToDouble(okuyucu_yedek_1["liste14"]);
                    yedek_profil[say_Git, 15] = Convert.ToDouble(okuyucu_yedek_1["liste15"]);
                    yedek_profil[say_Git, 16] = 0;//dizi 16=Label degeri...
                    say_Git++;
                }
            }
            baglanti.Close();
            MessageBox.Show("Butun elemanlar basarili sekilde diziye eklendi.");
            /*
              Degerler basarili sekilde veritabanindan alindi 
              simdi sirada sigmoid sacmaligi var ya ALLAH YA BISMILLAH
              */
        }
        private void button11_Click(object sender, EventArgs e)
        {//dataGridView tablosunun ici temizleniyor.
            dataGridView1.DataSource = "";
        }
        private void button5_Click(object sender, EventArgs e)
        {
            //OgrenciProfil dizisindeki veriler veritabanindaki ogrenciProfil tablosuna ekleniyor.
            veritabani_Ogrenci_Profil_Ekle();
            MessageBox.Show("Ogrenci_Profil Veritabanina Kayıt başarılı...");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            //alt fonksiyonla ogrenciNetwork dizisinden veriler ogrenciNetwork tablosuna ekleniyor.
            //eger dizinin ici bos ise sorun olacak buna cozum uretillmerli.
            //veriler once diziye eklendi sonra buton enabled olacak. o zorun cozulduç.
            veritabani_Ogrenci_Network_Ekle();
            MessageBox.Show("Ogrenci_Network Veritabanina Kayıt başarılı...");
        }

        private void button7_Click(object sender, EventArgs e)
        {//alt fonksiyon cagrilarak dosyadaki ogrenciListesi verileri diziye aktarildi.
            //simdi alt fonksiyonla veriler veritabanina ekleniyor.
            veritabani_Ogrenci_Listesi_Ekle();
            MessageBox.Show("OgrenciListesi Veritabanina Kayıt başarılı...");
        }

        private void button8_Click(object sender, EventArgs e)
        {
            //Ogrenci Profili Tabloda listelenecek...
            string kayit = "SELECT * from ogrenciProfil";
            verilerigoruntule(kayit);

        }

        private void button9_Click(object sender, EventArgs e)
        {//ogrencNetwork veritabanindan veriler dataGridView de listelenecek. tmm.
            string kayit = "SELECT * from ogrenciNetwork";
            verilerigoruntule(kayit);
        }

        private void button10_Click(object sender, EventArgs e)
        {//ogrenciListesi tablosundaki degerler dataGridView tablosunda listeleniyor.
            string kayit = "SELECT * from ogrenciListesi";
            verilerigoruntule(kayit);
        }

        private void button12_Click(object sender, EventArgs e)
        {//ogrenciProfil tablosundaki butun veriler temizleniyor.tmm.....
            string listeNeler = "Delete *from ogrenciProfil";
            veritabani_veri_Sil(listeNeler);
            MessageBox.Show("ogrenciProfil Veritabani temizleme başarılı...");
        }

        private void button13_Click(object sender, EventArgs e)
        {//ogrenciNetwork veritabanindaki butun veriler temizleniyor...
            string listeNeler = "Delete *from ogrenciNetwork";
            veritabani_veri_Sil(listeNeler);
            MessageBox.Show("ogrenciNetwork Veritabani temizleme başarılı...");
        }

        private void button14_Click(object sender, EventArgs e)
        {//ogrenciListesi tablosundaki butun veriler tamizleniyur.
            string listeNeler = "Delete *from ogrenciListesi";
            veritabani_veri_Sil(listeNeler);
            MessageBox.Show("ogrenciListesi Veritabani temizleme başarılı...");
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            //form ilk acildiginda
            //veritabanina kayir islemi yapilmamasi lazim.
            //verilerin once diziye aktarilmasi lazim.
            //boksa gereksiz verilerle dolar veritabanimizin ici.
            //o sebeple program baslangicinda veritabanina ekleme butonlari devre disi olmali.
            button5.Enabled = false;
            button6.Enabled = false;
            button7.Enabled = false;
        }
        //********************Loistik Regression icin gerekli komutlar ve fonksiyonlar*************************** 
        public void bi_Bak()
        {/*
            bi_bak fonksiyonu basit olarak 
            sadece weights dizisi icin degerler uretiyor.

          Bu fonksiyon B0,B1,B2...  B15 degerlerini weights[] disine ekliyor.
          dizideki degerleri signuma gonderilecek kivama getiriyor.
          ama signuma gondermiyoruz.
          elimizdeki diziyi classify() fonkisyonuna gonderiyoruz.. o hallediyor.
          classify() fonksiyonuna gitmeden once
          komut satirinda bu fonksiyona gelip weights[] dizisine degerler eklenmesi gerekiyor....
           yani bu fonkisyon kesinlikle calismali
          */
         //stepSize degeri.
            double rate = 0.01;
            //  for (int p = 0; p < weights.Length; p++)
            //  { weights[p] = 0; }

            //iterasyon adimlari.
            int ITERATIONS = 100;
            for (int n = 0; n < ITERATIONS; n++)
            {
                int sayac = 0;
                //
                for (int i = 0; i < profil.GetLength(0); i++)
                {
                    // if (profil[i, 0] == 0)
                    //  {break;}
                    //x: dizideki ogrencilerin liste degerleri.
                    int[] x = new int[15];
                    for (int eleman2 = 1; eleman2 < profil.GetLength(1) - 1; eleman2++)
                    { x[eleman2 - 1] = Convert.ToInt32(profil[i, eleman2]); }
                    double predicted = classify(x);
                    //ins x dizisi ve profil dizileri global degildir...
                    //weights dizisi 5 elemanlidir. bunun 15 elemanli olmasi gerek 
                    //weights disine b0,b1,b2...b15 degerleri aktarilacak... 
                    int label = Convert.ToInt32(profil[i, 16]);
                    for (int j = 0; j < weights.Length; j++)
                    {
                        if (j >= x.Length) break;
                        //+ isaretini - yap
                        weights[j] = weights[j] + rate * (label - predicted) * x[j];
                    }
                    sayac++;
                }//for profil.GetLength(0) dongu sonu
            }//iterasyon for sonu
            MessageBox.Show("İterasyon adimlari Basarili sekilde sonlandi.");
        }
        private double classify(int[] x)
        {
            double logit = .0;
            for (int i = 0; i < weights.Length; i++)
            {
                if (i >= x.Length) break;
                logit += weights[i] * x[i];
            }
            return sigmoid(logit);
        }
        private static double sigmoid(double z)
        {
            return 1.0 / (1.0 + Math.Exp(-z));
        }
        private void button15_Click(object sender, EventArgs e)
        {
            int satir = Convert.ToInt32(textBox2.Text);
            int sutun = Convert.ToInt32(textBox3.Text);
            MessageBox.Show(profil[satir, sutun].ToString());

        }

        private void button16_Click(object sender, EventArgs e)
        {
            int[] gonder = new int[15];
             bi_Bak();
            //logistic_Regression();
            for (int i = 0; i < yedek_profil.GetLength(0); i++)
            {
                for (int k = 1; k < yedek_profil.GetLength(1) - 1; k++)
                {
                    gonder[k - 1] = Convert.ToInt32(yedek_profil[i, k]);
                }
                yeni_arkadas_listesi[i, 0] = yedek_profil[i, 0];
                double sayi = classify(gonder);
                //  MessageBox.Show(yeni_arkadas_listesi[i, 0].ToString() + "" + sayi.ToString("0.########"));
                yeni_arkadas_listesi[i, 1] = sayi;
                //gonder dizisi gonderilmeye hazir.
            }

            //diziye ekleme islemi bitti.
            //sadece diziyi siralamak kaldi.
            //iki boyutlu diziyi siraliyor.
            //siralama islemini sigmoid degerlerine gore buyukten kucuge gore siraliyor.
            for (int i = 0; i < yeni_arkadas_listesi.GetLength(0); i++)
            {
                for (int j = 0; j < yeni_arkadas_listesi.GetLength(0); j++)
                {
                    if (yeni_arkadas_listesi[i, 1] > yeni_arkadas_listesi[j, 1])
                    {
                        double yedek = 0.0;
                        double yedek2 = 0.0;
                        yedek = yeni_arkadas_listesi[j, 1];
                        yedek2 = yeni_arkadas_listesi[j, 0];
                        yeni_arkadas_listesi[j, 1] = yeni_arkadas_listesi[i, 1];
                        yeni_arkadas_listesi[j, 0] = yeni_arkadas_listesi[i, 0];
                        yeni_arkadas_listesi[i, 1] = yedek;
                        yeni_arkadas_listesi[i, 0] = yedek2;
                    }
                }
            }
        }

        private void button17_Click(object sender, EventArgs e)
        {
            int satir = Convert.ToInt32(textBox4.Text);
            int sutun = Convert.ToInt32(textBox5.Text);
            MessageBox.Show(yeni_arkadas_listesi[satir, sutun].ToString());
        }

        private void button18_Click(object sender, EventArgs e)
        {
            //ogrNo,adSoyad
            int sayac_Bak = 0;
            baglanti.Open();
            DataTable dt = new DataTable("Tablo");
            dt.Columns.Add("OnerilenArkadasNo");
            dt.Columns.Add("AdSoyad");
            for (int i = 0; i < yeni_arkadas_listesi.GetLength(0); i++)
            {
                string liste_adres = "SELECT * from ogrenciListesi where ogrNo = '" + yeni_arkadas_listesi[i, 0].ToString() + "'";
                OleDbCommand kom1 = new OleDbCommand(liste_adres, baglanti);
                OleDbDataReader okuyucu1 = kom1.ExecuteReader();
                okuyucu1.Read();
                dt.Rows.Add(Convert.ToString(okuyucu1["ogrNo"]), Convert.ToString(okuyucu1["adSoyad"]));
                //MessageBox.Show("Arkadaslar listesine veriler ekleniyor:"+ profil[sayac_Bak, 0]);
                sayac_Bak++;
                if (sayac_Bak >= 10)
                { break; }
            }//for sonu
            baglanti.Close();
            DataSet ds = new DataSet("YeniDataSet");
            ds.Tables.Add(dt);
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "Tablo";
        }




/*
        private double semsettin(double b0, int[] x)
        {
            double logit = .0;
            logit += b0;//b0 + weights[0]*x[0] + weights[1]*x[1] + weights[2]*x[2] + ... + weights[14]*x[14];
            for (int i = 0; i < weights.Length; i++)
            {
                if (i >= x.Length) break;
                logit += weights[i] * x[i];
            }
            return sigmoid(logit);
        }

        double b0 = 1.0;
        private int[] xGetir(int n)
        {
            int[] x = new int[15];
            for (int i = 1; i < 16; i++)
            {
                x[i - 1] = Convert.ToInt32(profil[n, i]);
            }
            return x;
        }

        private void logistic_Regression()
        {
            //butun dizi degerlerin kullanilmaya hazir oldugunu dusunup bu fonksiyonu oyle yazacam.
            //global diziler 
            //weights[],x[],
        //    for (int i = 0; i < weights.Length; i++)
        //    { weights[i] = 1; }

            double b0_Ussu = .0;
            double[] BJ = new double[15];
            int maxIterSayisi = 100;
            double stepSize = 0.01;
            int n = profil.GetLength(0);
            int[] x = new int[15];
            int label = 0;
            for (int t = 1; t < maxIterSayisi; t++)
            {
                double toplam_Sembolu = 0;

                for (int i = 0; i < n; i++)
                {
                    x = xGetir(i);
                    label = Convert.ToInt32(profil[i, 16]);
                    toplam_Sembolu += semsettin(b0, x) - label;
                }
                b0_Ussu = b0 - stepSize * ((1 / n) * toplam_Sembolu);
                for (int j = 0; j < 15; j++)
                {
                    double toplam_Sembolu_ic = 0;
                    for (int i = 0; i < n; i++)
                    {
                        x = xGetir(i);
                        label = Convert.ToInt32(profil[i, 16]);
                        toplam_Sembolu_ic += (semsettin(b0, x) - label) * x[j];
                    }
                    BJ[j] = weights[j] - stepSize * ((1 / n) * (toplam_Sembolu_ic));
                }
            }
            b0 = b0_Ussu;
            for (int adim = 0; adim < 15; adim++)
            {
                weights[adim] = BJ[adim];
            }

        }*/
        private void button19_Click(object sender, EventArgs e)
        {
          //  logistic_Regression();
            MessageBox.Show("logistic_Regression() fonksiyonu basarill sekilde sonuclandi.");
        }

        private void button20_Click(object sender, EventArgs e)
        {
            string wegi="weights degerleri:\n";
            for(int i = 0; i < 15; i++)
            {
                wegi = wegi+ i+":"+weights[i].ToString()+"\n" ;
            }
            MessageBox.Show(wegi);
        }
    }
}
